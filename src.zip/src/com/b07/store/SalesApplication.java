package com.b07.store;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import com.b07.database.helper.DatabaseDriverHelper;
import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.inventory.Inventory;
import com.b07.inventory.InventoryImpl;
import com.b07.inventory.Item;
import com.b07.users.Account;
import com.b07.users.Admin;
import com.b07.users.Customer;
import com.b07.users.Employee;
import com.b07.users.EmployeeInterface;
import com.b07.inventory.ItemTypes;
import com.b07.users.ShoppingCart;
import com.b07.users.User;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;

public class SalesApplication {
  /**
   * This is the main method to run your entire program! Follow the "Pulling it together"
   * instructions to finish this off.
   * 
   * @param argv unused.
   */

  public static void main(String[] argv) {

    Connection connection = DatabaseDriverExtender.connectOrCreateDataBase();
    if (connection == null) {
      System.out.print("NOOO");
    }
    try {
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
      String input;
      if (argv[0].equals("-1")) {
        // If it is -1
        /*
         * TODO This is for the first run only! Add this code:
         * DatabaseDriverExtender.initialize(connection); Then add code to create your first
         * account, an administrator with a password Once this is done, create an employee account
         * as well.
         * 
         */
        DatabaseDriverExtender.initialize(connection);
        int adminRoleId = DatabaseInsertHelper.insertRole("ADMIN");
        int employeeRoleId = DatabaseInsertHelper.insertRole("EMPLOYEE");
        int customerRoleId = DatabaseInsertHelper.insertRole("CUSTOMER");
        int adminUserId = -1;
        int employeeUserId = -1;
        String adminName;
        System.out.println("You are creating an admin");
        adminName = CorrectInput.checkInputName();
        int adminAge;
        adminAge = CorrectInput.checkInputAge();
        String adminAddress;
        adminAddress = CorrectInput.checkInputAddress();
        String adminPassword;
        adminPassword = CorrectInput.checkInputPassword();
        try {
          adminUserId =
              DatabaseInsertHelper.insertNewUser(adminName, adminAge, adminAddress, adminPassword);
          System.out.println("Your id is " + adminUserId);
          DatabaseInsertHelper.insertUserRole(adminUserId, adminRoleId);
        } catch (Exception e) {
        }
        System.out.println("You are creating an employee");
        String employeeName;
        employeeName = CorrectInput.checkInputName();
        int employeeAge;
        employeeAge = CorrectInput.checkInputAge();
        String employeeAddress;
        employeeAddress = CorrectInput.checkInputAddress();
        String employeePassword;
        employeePassword = CorrectInput.checkInputPassword();
        try {
          employeeUserId = DatabaseInsertHelper.insertNewUser(employeeName, employeeAge,
              employeeAddress, employeePassword);
          System.out.println("Your id is " + employeeUserId);
          DatabaseInsertHelper.insertUserRole(employeeUserId, employeeRoleId);
        } catch (Exception e) {
        }
      } else if (argv[0].equals("1")) {

        // If it is 1
        /*
         * TODO In admin mode, the user must first login with a valid admin account This will allow
         * the user to promote employees to admins. Currently, this is all an admin can do.
         */
        int adminUserId = CorrectInput.checkDbUserId("ADMIN");
        Admin admin = (Admin) DatabaseSelectHelper.getUserDetails(adminUserId);
        CorrectInput.checkDbPassword(adminUserId, "ADMIN");
        System.out.println("Type 1 to promote the employee");
        System.out.println("Type 2 to view the historic sales records");
        System.out.println("Type 3 to view list of active account for given customer");
        System.out.println("Type 4 to view list of inactive account for given customer");
        System.out.println("Type 5 to serialize database");
        System.out.println("Type 6 to deserialize database");
        System.out.println("Type 7 to exit");
        input = bufferedReader.readLine();
        while (!input.equals("7")) {
          if (input.equals("1")) {
            int employeeId;
            employeeId = CorrectInput.checkDbUserId("EMPLOYEE");
            Employee employee = (Employee) DatabaseSelectHelper.getUserDetails(employeeId);
            admin.promoteEmployee(employee);
          } else if (input.equals("2")) {
            admin.printSales();
          } else if (input.equals("3")) {
            int userId = CorrectInput.checkDbUserId("CUSTOMER");
            List<Account> activeAccounts = admin.getAccounts(userId, 1);
            // Print out the active accounts' detail
            for(int i=0; i < activeAccounts.size(); i++) {
              System.out.println("ID:  " + activeAccounts.get(i).getAccountId());
              System.out.println("============================================");
              HashMap<Item, Integer> temItemList = activeAccounts.get(i).getShoppingCart().getItemsWithQuantity();
              for(Item item : temItemList.keySet()) {
                System.out.println("      " + item.getName() + ": " + temItemList.get(item));
              }
              System.out.println("============================================");
            }
          } else if (input.equals("4")) {
            int userId = CorrectInput.checkDbUserId("CUSTOMER");
            List<Account> inactiveAccounts = admin.getAccounts(userId, 0);
            // Print out the inactive accounts' detail
            for(int i=0; i < inactiveAccounts.size(); i++) {
              System.out.println("ID:  " + inactiveAccounts.get(i).getAccountId());
              System.out.println("============================================");
              HashMap<Item, Integer> temItemList = inactiveAccounts.get(i).getShoppingCart().getItemsWithQuantity();
              for(Item item : temItemList.keySet()) {
                System.out.println("      " + item.getName() + ": " + temItemList.get(item));
              }
              System.out.println("============================================");
            }
          }else if(input.equals("5")) {
            Serialization serialization = new Serialization();
            serialization.serialize(serialization);
          }else if(input.equals("6")) {
            Serialization serialization = new Serialization();
            System.out.println("Storing the current database version");
            serialization.serializeBackup(serialization);
            System.out.println("current database has been stored");
            Serialization object = CorrectInput.checkFileAddress();
            System.out.println("deserializing the given database version");
            DatabaseDriverHelper.reInitialize();
            object.updateDatabase(object);
            try {
              DatabaseSelectHelper.getUserDetails(adminUserId);
            } catch(Exception e) {
              System.out.println("The current admin is not in the reinitialized databse, please log in as another admin");
              adminUserId = CorrectInput.checkDbUserId("ADMIN");
              admin = (Admin)DatabaseSelectHelper.getUserDetails(adminUserId);
              CorrectInput.checkDbPassword(adminUserId, "ADMIN");
            }
            
          }
          
          System.out.println("Type 1 to promote the employee");
          System.out.println("Type 2 to view the historic sales records");
          System.out.println("Type 3 to view list of active account for given customer");
          System.out.println("Type 4 to view list of inactive account for given customer");
          System.out.println("Type 5 to serialize database");
          System.out.println("Type 6 to deserialize database");
          System.out.println("Type 7 to exit");
          input = bufferedReader.readLine();
        }
      } else {

        // If anything else - including nothing
        /*
         * TODO Create a context menu, where the user is prompted with: 1 - Employee Login 2 -
         * Customer Login 0 - Exit Enter Selection:
         */
        input = "1";
        while (!input.equals("0")) {
          System.out.println("Type 1 to log in as employee");
          System.out.println("Type 2 to log in as customer");
          System.out.println("Type 0 to exit");
          input = bufferedReader.readLine();
          if (input.equals("1")) {
            // If the user entered 1
            /*
             * TODO Create a context menu for the Employee interface Prompt the employee for their
             * id and password Attempt to authenticate them. If the Id is not that of an employee or
             * password is incorrect, end the session If the Id is an employee, and the password is
             * correct, create an EmployeeInterface object then give them the following options: 1.
             * authenticate new employee 2. Make new User 3. Make new account 4. Make new Employee
             * 5. Restock Inventory 6. Exit
             * 
             * Continue to loop through as appropriate, ending once you get an exit code (9)
             */
            int employeeId = CorrectInput.checkDbUserId("EMPLOYEE");
            CorrectInput.checkDbPassword(employeeId, "EMPLOYEE");
            Employee employee = (Employee) DatabaseSelectHelper.getUserDetails(employeeId);
            int itemId = -1;
            BigDecimal itemPrice = new BigDecimal("0.01");
            Inventory inventory = new InventoryImpl();
            for (ItemTypes item : ItemTypes.values()) {
              boolean existItem = false;
              try {
                for(Item dbItem: DatabaseSelectHelper.getAllItems()) {
                  if(item.toString().equals(dbItem.getName())) {
                    existItem = true;
                    break;
                  }
                }
              }catch(Exception e) {
              }
              if (!existItem) {
                System.out.println("Type the price for item: " + item.toString());
                itemPrice = CorrectInput.checkInputPrice();
                itemId = DatabaseInsertHelper.insertItem(item.toString(), itemPrice);
                DatabaseInsertHelper.insertInventory(itemId, 0);
              }
            }
            EmployeeInterface employeeInterace = new EmployeeInterface(employee, inventory);
            System.out.println("Type 1 to authenticate new employee");
            System.out.println("Type 2 to make new customer");
            System.out.println("Type 3 to make new account");
            System.out.println("Type 4 to make new employee");
            System.out.println("Type 5 to restock inventory");
            System.out.println("Type 6 to exit");
            input = bufferedReader.readLine();
            while (!input.equals("6")) {
              int customerRoleId = -1;
              int employeeRoleId = -1;
              List<Integer> roleIds = DatabaseSelectHelper.getRoleIds();
              for (int i = 0; i < roleIds.size(); i++) {
                if (DatabaseSelectHelper.getRoleName(roleIds.get(i)).equals("CUSTOMER")) {
                  customerRoleId = roleIds.get(i);
                } else if (DatabaseSelectHelper.getRoleName(roleIds.get(i)).equals("EMPLOYEE")) {
                  employeeRoleId = roleIds.get(i);
                }
              }
              if (input.equals("1")) {
                employeeId = CorrectInput.checkDbUserId("EMPLOYEE");
                employeeInterace
                    .setCurrentEmployee((Employee) DatabaseSelectHelper.getUserDetails(employeeId));
              } else if (input.equals("2")) {
                System.out.println("You are creating a customer");
                int customerUserId;
                String customerName = CorrectInput.checkInputName();
                int customerAge = CorrectInput.checkInputAge();
                String customerAddress = CorrectInput.checkInputAddress();
                String customerPassword = CorrectInput.checkInputPassword();
                try {
                  customerUserId = DatabaseInsertHelper.insertNewUser(customerName, customerAge,
                      customerAddress, customerPassword);
                  System.out.println("your id is " + customerUserId);
                  DatabaseInsertHelper.insertUserRole(customerUserId, customerRoleId);
                } catch (Exception e) {
                }
              } else if (input.equals("3")) {
                int customerId = CorrectInput.checkDbUserId("CUSTOMER");
                int accountId = DatabaseInsertHelper.insertAccount(customerId);
                System.out
                    .println("The customer: " + customerId + "'s account id is: " + accountId);
              } else if (input.equals("4")) {
                int employeeUserId;
                System.out.println("You are creating an employee");
                String employeeName;
                employeeName = CorrectInput.checkInputName();
                int employeeAge;
                employeeAge = CorrectInput.checkInputAge();
                String employeeAddress;
                employeeAddress = CorrectInput.checkInputAddress();
                String employeePassword;
                employeePassword = CorrectInput.checkInputPassword();
                try {
                  employeeUserId = DatabaseInsertHelper.insertNewUser(employeeName, employeeAge,
                      employeeAddress, employeePassword);
                  System.out.println("your id is " + employeeUserId);
                  DatabaseInsertHelper.insertUserRole(employeeUserId, employeeRoleId);
                } catch (Exception e) {
                }

              } else if (input.equals("5")) {
                int quantity;
                itemId = CorrectInput.checkInputItemId();
                quantity = CorrectInput.checkInputItemQuantity();
                DatabaseUpdateHelper.updateInventoryQuantity(quantity, itemId);
              }
              System.out.println("Type 1 to authenticate new employee");
              System.out.println("Type 2 to make new customer");
              System.out.println("Type 3 to make new account");
              System.out.println("Type 4 to make new employee");
              System.out.println("Type 5 to restock inventory");
              System.out.println("Type 6 to exit");
              input = bufferedReader.readLine();
            }
            continue;
          } else if (input.equals("2")) {
            // If the user entered 2
            /*
             * TODO create a context menu for the customer Shopping cart Prompt the customer for
             * their id and password Attempt to authenticate them If the authentication fails or
             * they are not a customer, repeat If they get authenticated and are a customer, give
             * them this menu: 1. List current items in cart 2. Add a quantity of an item to the
             * cart 3. Check total price of items in the cart 4. Remove a quantity of an item from
             * the cart 5. check out 6. Exit
             * 
             * When checking out, be sure to display the customers total, and ask them if they wish
             * to continue shopping for a new order
             * 
             * For each of these, loop through and continue prompting for the information needed
             * Continue showing the context menu, until the user gives a 6 as input.
             */
            int customerId;
            customerId = CorrectInput.checkDbUserId("CUSTOMER");
            CorrectInput.checkDbPassword(customerId, "CUSTOMER");
            Customer dbCustomer = (Customer) DatabaseSelectHelper.getUserDetails(customerId);
            Customer customer = new Customer(dbCustomer.getId(), dbCustomer.getName(),
                dbCustomer.getAge(), dbCustomer.getAddress(), true);
            ShoppingCart shoppingCart = new ShoppingCart(customer);
            System.out.println("Type 1 to list current items in cart");
            System.out.println("Type 2 to add quantity of an item to cart");
            System.out.println("Type 3 Check total price of items in the cart");
            System.out.println("Type 4 to remove a quantity of an item form the cart");
            System.out.println("Type 5 to check out");
            System.out.println("Type 6 to create account id");
            System.out.println("Type 7 to log in account");
            System.out.println("Type 8 to exit");
            input = bufferedReader.readLine();
            while (!input.equals("8")) {
              if (input.equals("1")) {
                System.out.println("Current List:");
                List<Item> items = shoppingCart.getItems();
                for (int i = 0; i < items.size(); i++) {
                  System.out.println("Name: " + items.get(i).getName());
                }
              } else if (input.equals("2")) {
                int quantity = -1;
                int itemId;
                itemId = CorrectInput.checkInputItemId();
                Item item = DatabaseSelectHelper.getItem(itemId);
                quantity = CorrectInput.checkInputItemQuantity();
                shoppingCart.addItem(item, quantity);
              } else if (input.equals("3")) {
                System.out.println(shoppingCart.getTotal());

              } else if (input.equals("4")) {
                int quantity;
                int itemId;
                itemId = CorrectInput.checkInputItemId();
                Item item = DatabaseSelectHelper.getItem(itemId);
                quantity = CorrectInput.checkInputItemQuantity();
                shoppingCart.removeItem(item, quantity);
              } else if (input.equals("5")) {
                BigDecimal priceAfterTax =
                    shoppingCart.getTotal().multiply(shoppingCart.getTaxRate());
                if (shoppingCart.checkOut()) {
                  System.out.println("You've paid" + priceAfterTax + ", Thank you!");
                  //System.out.println("Would you like have a new order");
                }else {
                  System.out.println("Something goes wrong, sorry");
                }
              } else if (input.equals("6")) {
                // new feature
                // should delete the code and implement it in the android
                int accountId = DatabaseInsertHelper.insertAccount(customerId);
                HashMap<Item, Integer> items = shoppingCart.getItemsWithQuantity();
                for (Item item : items.keySet()) {
                  DatabaseInsertHelper.insertAccountLine(accountId, item.getId(), items.get(item));
                }
                System.out.println("Success! Your account id is: " + accountId);
              } else if (input.equals("7")) {
                int accountid = CorrectInput.checkAccountId(customerId);
                if (accountid == -1) {
                  System.out.println("You don't have an account id, you can choose other choices");
                } else {
                  Account account = DatabaseSelectHelper.getAccountDetails(accountid);
                  // Create a shopping cart to represent the restoring
                  ShoppingCart currentShoppingCart = new ShoppingCart(customer);
                  // Check do current inventory has enough quantity of items that in the cart
                  for (Item item : account.getShoppingCart().getItemsWithQuantity().keySet()) {
                    if (DatabaseSelectHelper.getInventoryQuantity(item.getId()) < account
                        .getShoppingCart().getItemsWithQuantity().get(item)) {
                      // if not enough, current cart would just add the amount of item the inventory
                      // has
                      currentShoppingCart.addItem(item,
                          DatabaseSelectHelper.getInventoryQuantity(item.getId()));
                      System.out.println(
                          "We only have " + DatabaseSelectHelper.getInventoryQuantity(item.getId())
                              + " " + item.getName()
                              + "(s) in the stock, so we change the quantity in your cart");
                    } else {
                      // else, just add
                      currentShoppingCart.addItem(item,
                          account.getShoppingCart().getItemsWithQuantity().get(item));
                    }
                  }
                  shoppingCart = currentShoppingCart;
                  System.out.println("Type 1 to check out");
                  System.out.println("Type 2 to pay it later");
                  input = bufferedReader.readLine();
                  if (input.equals("1")) {
                    BigDecimal priceAfterTax =
                        shoppingCart.getTotal().multiply(shoppingCart.getTaxRate());
                    if (shoppingCart.checkOut()) {
                      DatabaseUpdateHelper.updateAccountStatus(accountid, false);
                      System.out.println("You've paid" + priceAfterTax + ", Thank you!");
                    }else {
                      System.out.println("Something goes wrong, sorry");
                    }
                  }
                }
              }
              System.out.println("Type 1 to list current items in cart");
              System.out.println("Type 2 to add quantity of an item to cart");
              System.out.println("Type 3 Check total price of items in the cart");
              System.out.println("Type 4 to remove a quantity of an item form the cart");
              System.out.println("Type 5 to check out");
              System.out.println("Type 6 to create account id");
              System.out.println("Type 7 to log in account");
              System.out.println("Type 8 to exit");
              input = bufferedReader.readLine();

            }
            continue;
          } else if (input.equals("0")) {
            break;
          } else {
            System.out.println("Wrong input, try again");
            System.out.println("Type 1 to log in as employee");
            System.out.println("Type 2 to log in as customer");
            System.out.println("Type 0 to exit");
            input = bufferedReader.readLine();
          }
        }
        System.out.println("The program will be terminated");
        System.exit(1);
        // If the user entered 0
        /*
         * TODO Exit condition
         */
        // If the user entered anything else:
        /*
         * TODO Re-prompt the user
         */
      }
    } catch (Exception e) {
     e.printStackTrace();
    } finally {
      try {
        connection.close();
      } catch (Exception e) {
        System.out.println("Looks like it was closed already :)");
      }
    }

  }

}
