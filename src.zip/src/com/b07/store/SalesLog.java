package com.b07.store;

import java.util.List;

public interface SalesLog {
/**
 * 
 * @param sale a sale need to be added
 */
  public void addSaleLog(Sale sale);

  /**
   * 
   * @param sale a sale need to be deleted
   */
  public void deleteSaleLog(Sale sale);

  /**
   * @return the list of sale, which is the saleslog.
   */
  public List<Sale> getSalesLog();
}
