package com.b07.store;

import java.util.ArrayList;
import java.util.List;

public class SalesLogImpl implements SalesLog {
  private List<Sale> saleLog;

  public SalesLogImpl() {
    this.saleLog = new ArrayList<Sale>();
  }

  public SalesLogImpl(List<Sale> saleLog) {
    this.saleLog = saleLog;
  }

  @Override
  public void addSaleLog(Sale sale) {
    saleLog.add(sale);
  }

  @Override
  public void deleteSaleLog(Sale sale) {
    saleLog.remove(sale);
  }

  @Override
  public List<Sale> getSalesLog() {
    return this.saleLog;
  }
}
