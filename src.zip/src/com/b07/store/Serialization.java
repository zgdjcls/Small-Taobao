package com.b07.store;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.exceptions.NotLoginException;
import com.b07.inventory.Inventory;
import com.b07.inventory.Item;
import com.b07.users.Account;
import com.b07.users.User;

public class Serialization implements Serializable {
  // Integer: role id String: role name
  private HashMap<Integer, String> role = new HashMap<>();
  // Integer: item id
  private HashMap<Integer, Item> item = new HashMap<>();
  // First integer: item id Second integer: item quantity
  private HashMap<Integer, Integer> itemInventory = new HashMap<>();
  // Integer: sale id
  private HashMap<Integer, Sale> sale = new HashMap<>();
  // Integer: user id
  private HashMap<Integer, User> user = new HashMap<>();
  // First Integer: user id Second Integer: role id
  private HashMap<Integer, Integer> userRole = new HashMap<>();
  // Integer: user id String: user password
  private HashMap<Integer, String> userPW = new HashMap<>();
  // First Integer: account id Second Integer: user id
  private HashMap<Integer, Integer> userAccount = new HashMap<>();
  // Integer: account id
  private HashMap<Integer, Account> account = new HashMap<>();
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  public Serialization() throws SQLException, DatabaseSelectException, NotLoginException {
    List<Integer> roleId = DatabaseSelectHelper.getRoleIds();
    for (int i = 1; i <= roleId.size(); i++) {
      role.put(i, DatabaseSelectHelper.getRoleName(i));
    }
    List<Item> items = DatabaseSelectHelper.getAllItems();
    for (int i = 1; i <= items.size(); i++) {
      item.put(i, DatabaseSelectHelper.getItem(i));
      itemInventory.put(i, DatabaseSelectHelper.getInventoryQuantity(i));
    }
    SalesLog salesLog = DatabaseSelectHelper.getSales();
    for (int i = 1; i <= salesLog.getSalesLog().size(); i++) {
      sale.put(i, DatabaseSelectHelper.getItemizedSaleById(i));
    }
    List<User> users = DatabaseSelectHelper.getUsersDetails();
    for (int i = 1; i <= users.size(); i++) {
      user.put(i, DatabaseSelectHelper.getUserDetails(i));
      userRole.put(i, DatabaseSelectHelper.getUserRoleId(i));
      userPW.put(i, DatabaseSelectHelper.getPassword(i));
      List<Integer> accounts = DatabaseSelectHelper.getUserAccounts(i);
      for (int j = 0; j < accounts.size(); j++) {
        userAccount.put(accounts.get(j), i);
        account.put(accounts.get(j), DatabaseSelectHelper.getAccountDetails(j));
      }

    }


  }

  /**
   * 
   * @param x an object which store the data of database
   * @return the storing place
   */
  public static String serialize(Serializable x) {
    try {
      FileOutputStream fileOut = new FileOutputStream("/Users/zhengyiming/Desktop/database_copy.ser");
      ObjectOutputStream out = new ObjectOutputStream(fileOut);
      out.writeObject(x);
      out.close();
      fileOut.close();
      System.out.println("Serialized data is saved in /Users/zhengyiming/Desktop/database_copy.ser");
    } catch (IOException i) {
      i.printStackTrace();
    }
    return x.toString();
  }
  
  /**
   * 
   * @param x an object which store the data of database
   * @return the storing place
   */
  public static String serializeBackup(Serializable x) {
    try {
      FileOutputStream fileOut = new FileOutputStream("/Users/zhengyiming/Desktop/database_copy_Backup.ser");
      ObjectOutputStream out = new ObjectOutputStream(fileOut);
      out.writeObject(x);
      out.close();
      fileOut.close();
      System.out.println("Serialized data is saved in /Users/zhengyiming/Desktop/database_copy_Backup.ser");
    } catch (IOException i) {
      i.printStackTrace();
    }
    return x.toString();
  }

  /**
   * 
   * @param fileName where is object is
   * @return a object that save the data of database
   */
  public static Object deserialize(String fileName) {
    try {
      FileInputStream fileIn = new FileInputStream(fileName);
      ObjectInputStream in = new ObjectInputStream(fileIn);
      Object z = in.readObject();
      in.close();
      fileIn.close();
      return z;
    } catch (IOException i) {
      i.printStackTrace();
      return null;
    } catch (ClassNotFoundException c) {
      System.out.println("Cat class not found");
      c.printStackTrace();
      return null;
    }
  }

  /**
   * Read the data inside the object to rebuild a new database
   * @param object the serialize database
   * @return True if succeed, False otherwise
   */
  public static boolean updateDatabase(Serialization object) {
    try {
      // Role Insertion with order
      for(int i=1;i<=object.role.size();i++) {
        DatabaseInsertHelper.insertRole(object.role.get(i));
      }
      // Item and Inventory with order
      for(int i=1;i <= object.item.size();i++) {
        Item item = object.item.get(i);
        DatabaseInsertHelper.insertItem(item.getName(), item.getPrice());
        DatabaseInsertHelper.insertInventory(i, object.itemInventory.get(i));
      }
      // User with order
      for(int i=1;i<= object.user.size();i++) {
        User user = object.user.get(i);
        DatabaseInsertHelper.insertDeserializeNewUser(user.getName(), user.getAge(), user.getAddress(), object.userPW.get(i));
        DatabaseInsertHelper.insertUserRole(i, object.userRole.get(user.getId()));
      }
      // Sales
      for(int i=1; i <= object.sale.size();i++) {
        Sale sale = object.sale.get(i);
        DatabaseInsertHelper.insertSale(sale.getUser().getId(),sale.getTotalPrice());
        for(Item item: sale.getItemMap().keySet()) {
          DatabaseInsertHelper.insertItemizedSale(i, item.getId(), sale.getItemMap().get(item));
        }
      }
      // Account with order
      for(int i=1; i <= object.account.size();i++) {
        DatabaseInsertHelper.insertAccount(object.userAccount.get(i));
        boolean active;
        if(object.account.get(i).getAccountActive() == 1) {
          active = true;
        } else {
          active = false;
        }
        DatabaseUpdateHelper.updateAccountStatus(i, active);
        for(Item item: object.account.get(i).getShoppingCart().getItemsWithQuantity().keySet()) {
          DatabaseInsertHelper.insertAccountLine(i, item.getId(), object.account.get(i).getShoppingCart().getItemsWithQuantity().get(item));
        }
      }
      System.out.println("Database has been reinitialzed");
      return true;
    }catch(Exception e) {
      e.printStackTrace();
      System.out.println("Error happened during reintializeing, please reinitialize the previous version");
    }
    return false;
  }

}
