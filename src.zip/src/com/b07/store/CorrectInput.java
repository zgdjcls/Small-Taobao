package com.b07.store;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.users.Admin;
import com.b07.users.Customer;
import com.b07.users.Employee;

public class CorrectInput {
  static BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

  /**
   * @return the correct name based on the handout
   * @throws IOException if something goes wrong
   */
  public static String checkInputName() throws IOException {
    String name = "";
    System.out.println("Please type your name");
    while (true) {
      name = bufferedReader.readLine();
      if (name.equals(null) || name.isBlank() || name.length() > 64) {
        System.out.println("Name cannot be empty, null or longer than 64 characters");
        System.out.println("Please type your name");
      } else {
        break;
      }
    }
    return name;
  }

  /**
   * 
   * @return the correct address based on the handout
   * @throws IOException if something goes wrong
   */
  public static String checkInputAddress() throws IOException {
    String address = "";
    System.out.println("Please type your address");
    while (true) {
      address = bufferedReader.readLine();
      if (address.equals(null) || address.isBlank() || address.length() > 100) {
        System.out.println("Address cannot be empty, null or longer than 100 characters");
        System.out.println("Please type your address");
      } else {
        break;
      }
    }
    return address;
  }

  /**
   * 
   * @return the correct password which cannot be empty or null
   * @throws IOException if something goes wrong
   */
  public static String checkInputPassword() throws IOException {
    String password = "";
    System.out.println("Please type your password");
    while (true) {
      password = bufferedReader.readLine();
      if (password.equals(null) || password.isBlank()) {
        System.out.println("Password cannot be empty or null");
        System.out.println("Please type your password");
      } else {
        break;
      }
    }
    return password;
  }

  /**
   * 
   * @return the correct age based on the handout
   */
  public static int checkInputAge() {
    int age = -1;
    System.out.println("Please type your age");
    while (true) {
      try {
        age = Integer.parseInt(bufferedReader.readLine());
      } catch (Exception e) {
        age = -1;
      }
      if (age < 0) {
        System.out.println("Age cannot be less than 0 or non-integer value");
        System.out.println("Please type your age");
      } else {
        break;
      }
    }
    return age;
  }

  /**
   * 
   * @param role the role name in Roles
   * @return the existing user id in database whose role is parameter "role"
   * @throws SQLException if something goes wrong
   * @throws DatabaseSelectException if something goes wrong
   */
  public static int checkDbUserId(String role) throws SQLException, DatabaseSelectException {
    List<Integer> roleIds = DatabaseSelectHelper.getRoleIds();
    int roleId = -1;
    int userId = -1;
    int temUserRoleId = 0;
    if (role.equals("ADMIN")) {
      // gain the correct roleId for ADMIN;
      for (int i = 0; i < roleIds.size(); i++) {
        if (DatabaseSelectHelper.getRoleName(roleIds.get(i)).equals(role)) {
          roleId = roleIds.get(i);
        }
      }
      boolean wrongAdminId = true;
      while (wrongAdminId) {
        System.out.println("Type your id for admin account");
        try {
          userId = Integer.parseInt(bufferedReader.readLine());
          temUserRoleId = DatabaseSelectHelper.getUserRoleId(userId);
        } catch (Exception e) {
          System.out.println("Wrong id, try again");
          userId = -1;
          continue;
        }
        if (userId > 0 && temUserRoleId == roleId) {
          wrongAdminId = false;
        } else {
          System.out.println("The User with input id is not an admin");
        }
      }
    } else if (role.equals("EMPLOYEE")) {
      // gain the correct roleId for EMPLOYEE;
      for (int i = 0; i < roleIds.size(); i++) {
        if (DatabaseSelectHelper.getRoleName(roleIds.get(i)).equals(role)) {
          roleId = roleIds.get(i);
        }
      }
      boolean wrongEmployeeId = true;
      while (wrongEmployeeId) {
        System.out.println("Type your id for employee account");
        try {
          userId = Integer.parseInt(bufferedReader.readLine());
          temUserRoleId = DatabaseSelectHelper.getUserRoleId(userId);
        } catch (Exception e) {
          System.out.println("Wrong id, try again");
          userId = -1;
          continue;
        }
        if (userId > 0 && temUserRoleId == roleId) {
          wrongEmployeeId = false;
        } else {
          System.out.println("The User with input id is not an employee");
        }
      }
    } else if (role.equals("CUSTOMER")) {
      // gain the correct roleId for CUSTOMER;
      for (int i = 0; i < roleIds.size(); i++) {
        if (DatabaseSelectHelper.getRoleName(roleIds.get(i)).equals(role)) {
          roleId = roleIds.get(i);
        }
      }
      boolean wrongCustomerId = true;
      while (wrongCustomerId) {
        System.out.println("Type your id for customer account");
        try {
          userId = Integer.parseInt(bufferedReader.readLine());
          temUserRoleId = DatabaseSelectHelper.getUserRoleId(userId);
        } catch (Exception e) {
          System.out.println("Wrong id, try again");
          userId = -1;
          continue;
        }
        if (userId > 0 && temUserRoleId == roleId) {
          wrongCustomerId = false;
        } else {
          System.out.println("The User with input id is not an customer");
        }
      }
    }
    return userId;
  }

  /**
   * 
   * @param userId the user id in database
   * @param role the role in Roles
   * @return the correct password of the given userId whose role is parameter "role"
   * @throws SQLException
   * @throws DatabaseSelectException
   * @throws IOException
   */
  public static String checkDbPassword(int userId, String role)
      throws SQLException, DatabaseSelectException, IOException {
    String password = "";
    if (role.equals("ADMIN")) {
      Admin admin = (Admin) DatabaseSelectHelper.getUserDetails(userId);
      boolean wrongPassword = true;
      while (wrongPassword) {
        System.out.println("Please type your password");
        password = bufferedReader.readLine();
        if (admin.authenticate(password)) {
          wrongPassword = false;
        } else {
          System.out.println("wrong password, try again");
        }
      }
    } else if (role.equals("EMPLOYEE")) {
      Employee employee = (Employee) DatabaseSelectHelper.getUserDetails(userId);
      boolean wrongPassword = true;
      while (wrongPassword) {
        System.out.println("Please type your password");
        password = bufferedReader.readLine();
        if (employee.authenticate(password)) {
          wrongPassword = false;
        } else {
          System.out.println("wrong password, try again");
        }
      }
    } else if (role.equals("CUSTOMER")) {
      Customer customer = (Customer) DatabaseSelectHelper.getUserDetails(userId);
      boolean wrongPassword = true;
      while (wrongPassword) {
        System.out.println("Please type your password");
        password = bufferedReader.readLine();
        if (customer.authenticate(password)) {
          wrongPassword = false;
        } else {
          System.out.println("wrong password, try again");
        }
      }
    }
    return password;
  }

  /**
   * 
   * @return the correct price which cannot be less than 0 or not doesn't have exactly 2 decimals
   */
  public static BigDecimal checkInputPrice() {
    BigDecimal itemPrice = new BigDecimal("0.00");
    while (true) {
      try {
        itemPrice = new BigDecimal(bufferedReader.readLine());
        if (itemPrice.floatValue() > 0 && itemPrice.scale() == 2) {
          break;
        }
      } catch (Exception e) {
        System.out.println("Price must have 2 decimals and be positive");
        System.out.println("Type the price");
      }
    }
    return itemPrice;
  }

  /**
   * 
   * @return the exsiting item id in database
   */
  public static int checkInputItemId() {
    int itemId = -1;
    System.out.println("Type the item id: ");
    while (true) {
      try {
        itemId = Integer.parseInt(bufferedReader.readLine());
        DatabaseSelectHelper.getItem(itemId);
        break;
      } catch (Exception e) {
        System.out.println("Wrong id, try again.");
        System.out.println("Type the item id: ");
      }
    }
    return itemId;
  }

  /**
   * 
   * @return the correct quantity which cannot be less or equal to 0
   */
  public static int checkInputItemQuantity() {
    int quantity = -1;
    System.out.println("Type the item quantity: ");
    while (true) {
      try {
        quantity = Integer.parseInt(bufferedReader.readLine());
        if (quantity > 0) {
          break;
        } else {
          System.out.println("Wrong quantity, try again");
          System.out.println("Type the item quantity: ");
        }
      } catch (Exception e) {
        System.out.println("Wrong quantity, try again");
        System.out.println("Type the item quantity: ");
      }
    }
    return quantity;
  }
  /**
   * 
   * @param customerId the id of customer
   * @return an existing account id in database of the given customer
   */
  public static int checkAccountId(int customerId) {
    int accountId = -1;
    System.out.println("Type the account id for customer: " + customerId);
    while (true) {
      try {
        boolean rightId = false;
        accountId = Integer.parseInt(bufferedReader.readLine());
        List<Integer> accountIds = DatabaseSelectHelper.getUserAccounts(customerId);
        if(accountIds.isEmpty()) {
        	accountId = -1;
        	break;
        }
        for (int id : accountIds) {
          if (id == accountId) {
            rightId = true;
          }
        }
        if(rightId) {
          break;
        }else {
        	System.out.println("Wrong id, try again");
            System.out.println("Type the account id for customer: " + customerId);
        }
      } catch (Exception e) {
        System.out.println("Wrong id, try again");
        System.out.println("Type the account id for customer: " + customerId);
      }
    }
    return accountId;
  }
  
  /**
   * Check if the file exists.
   * @return a deserialize object, NULL if there doesn't exist.
   */
  public static Serialization checkFileAddress(){
    String address;
    System.out.println("Type the file address of serizalize object");
    Serialization object = null;
    while(true) {
      try {
        address =  bufferedReader.readLine();
        object = (Serialization) object.deserialize(address);
        if(object != null) {
          break;
        }
      }catch(Exception e) {
      }
      System.out.println("Wrong address, try again");
      System.out.println("Type the file address of serizalize object");
    }
    return object;
    
  }
}
