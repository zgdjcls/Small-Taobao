package com.b07.database.helper;

import com.b07.database.DatabaseSelector;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.exceptions.NotLoginException;
import com.b07.inventory.Inventory;
import com.b07.inventory.InventoryImpl;
import com.b07.inventory.Item;
import com.b07.inventory.ItemImpl;
import com.b07.store.Sale;
import com.b07.store.SaleImpl;
import com.b07.store.SalesLog;
import com.b07.store.SalesLogImpl;
import com.b07.users.Account;
import com.b07.users.Admin;
import com.b07.users.Customer;
import com.b07.users.Employee;
import com.b07.users.ShoppingCart;
import com.b07.users.User;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DatabaseSelectHelper extends DatabaseSelector {
  /**
   * @return a list of all userIds in the table
   * @throws SQLException thrown if an SQLException occurs.
   */
  private static List<Integer> getuserIds() throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getUsersDetails(connection);
    List<Integer> ids = new ArrayList<>();
    while (results.next()) {
      ids.add(results.getInt("ID"));
    }
    results.close();
    connection.close();
    return ids;
  }

  /**
   * 
   * @return a list of all itemIds in the table
   * @throws SQLException thrown if an SQLException occurs.
   */
  private static List<Integer> getAllItemsId() throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getAllItems(connection);
    List<Integer> itemsId = new ArrayList<>();
    while (results.next()) {
      int id = results.getInt("ID");
      itemsId.add(id);
    }
    results.close();
    connection.close();
    return itemsId;
  }

  /**
   * 
   * @param id      the userId
   * @param name    the user name
   * @param age     the user age
   * @param address the user age
   * @param roleId  the user roleId
   * @return a Admin, Employee or Customer object of given information, role
   *         depends on roleId
   * @throws SQLException            thrown if an SQLException occurs.
   * @throws DatabaseSelectException if the input is invalid.
   */
  private static User createUser(int id, String name, int age, String address, int roleId)
      throws SQLException, DatabaseSelectException {
    User user = null;
    if (getRoleName(roleId).equals("ADMIN")) {
      user = new Admin(id, name, age, address);
    } else if (getRoleName(roleId).equals("EMPLOYEE")) {
      user = new Employee(id, name, age, address);
    } else if (getRoleName(roleId).equals("CUSTOMER")) {
      user = new Customer(id, name, age, address);
    }
    return user;
  }

  /**
   * 
   * @return a list of all saleIds in the table
   * @throws SQLException thrown if an SQLException occurs.
   */
  private static List<Integer> getSalesId() throws SQLException {
    List<Integer> ids = new ArrayList<>();
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getSales(connection);
    while (results.next()) {
      ids.add(results.getInt("ID"));
    }
    results.close();
    connection.close();
    return ids;
  }

  /**
   * get all the roles.
   * 
   * @return a ResultSet containing all rows of the roles table.
   * @throws SQLException thrown if an SQLException occurs.
   */
  public static List<Integer> getRoleIds() throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getRoles(connection);
    List<Integer> ids = new ArrayList<>();
    while (results.next()) {
      ids.add(results.getInt("ID"));
    }
    results.close();
    connection.close();
    return ids;
  }

  /**
   * get the role with id id.
   * 
   * @param id the id of the role
   * @return a String containing the role.
   * @throws SQLException            thrown when something goes wrong with query
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static String getRoleName(int roleId) throws SQLException, DatabaseSelectException {
    List<Integer> ids = getRoleIds();
    boolean checkExist = false;
    for (int i = 0; i < ids.size(); i++) {
      if (roleId == ids.get(i)) {
        checkExist = true;
      }
    }
    String role = "";
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      role = DatabaseSelector.getRole(roleId, connection);
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return role;
  }

  /**
   * get the role of the given user.
   * 
   * @param userId the id of the user.
   * @return the roleId for the user.
   * @throws SQLException            thrown if something goes wrong with the
   *                                 query.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static int getUserRoleId(int userId) throws SQLException, DatabaseSelectException {
    List<Integer> userIds = getuserIds();
    boolean checkExist = false;
    for (int i = 0; i < userIds.size(); i++) {
      if (userId == userIds.get(i)) {
        checkExist = true;
      }
    }
    int roleId = -1;
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      roleId = DatabaseSelector.getUserRole(userId, connection);
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }

    return roleId;
  }

  /**
   * get the role of the given user.
   * 
   * @param roleId the id of the role.
   * @return the list of userIds with same roleId.
   * @throws SQLException            thrown if something goes wrong with the
   *                                 query.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static List<Integer> getUsersByRole(int roleId) throws SQLException, DatabaseSelectException {
    List<Integer> ids = getRoleIds();
    List<Integer> userIds = new ArrayList<>();
    boolean checkExist = false;
    for (int i = 0; i < ids.size(); i++) {
      if (roleId == ids.get(i)) {
        checkExist = true;
      }
    }
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUsersByRole(roleId, connection);
      while (results.next()) {
        userIds.add(results.getInt("USERID"));
      }
      results.close();
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return userIds;

  }

  /**
   * Return all users from the database.
   * 
   * @return a list of users that stored in the table.
   * @throws SQLException            thrown if there is an issue.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static List<User> getUsersDetails() throws SQLException, DatabaseSelectException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getUsersDetails(connection);
    List<User> users = new ArrayList<>();
    while (results.next()) {
      int id = results.getInt("ID");
      String name = results.getString("NAME");
      int age = results.getInt("AGE");
      String address = results.getString("ADDRESS");
      Integer roleId = getUserRoleId(id);
      User user = createUser(id, name, age, address, roleId);
      users.add(user);
    }
    results.close();
    connection.close();
    return users;
  }

  /**
   * find all the details about a given user.
   * 
   * @param userId the id of the user.
   * @return a result set with the details of the user.
   * @throws SQLException            thrown when something goes wrong with query.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static User getUserDetails(int userId) throws SQLException, DatabaseSelectException {
    User user = null;
    List<Integer> userIds = getuserIds();
    boolean checkExist = false;
    for (int i = 0; i < userIds.size(); i++) {
      if (userId == userIds.get(i)) {
        checkExist = true;
      }
    }
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUserDetails(userId, connection);
      while (results.next()) {
        int id = results.getInt("ID");
        String name = results.getString("NAME");
        int age = results.getInt("AGE");
        String address = results.getString("ADDRESS");
        Integer roleId = getUserRoleId(id);
        user = createUser(id, name, age, address, roleId);
      }
      results.close();
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return user;
  }

  /**
   * get the hashed version of the password.
   * 
   * @param userId the user's id.
   * @return the hashed password to be checked against given password.
   * @throws SQLException            if a database issue occurs.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static String getPassword(int userId) throws SQLException, DatabaseSelectException {
    List<Integer> userIds = getuserIds();
    boolean checkExist = false;
    for (int i = 0; i < userIds.size(); i++) {
      if (userId == userIds.get(i)) {
        checkExist = true;
      }
    }
    String password = "";
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      password = DatabaseSelector.getPassword(userId, connection);
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return password;
  }

  /**
   * get all rows from the items table.
   * 
   * @return a list of all items and associated values.
   * @throws SQLException if anything goes wrong.
   */
  public static List<Item> getAllItems() throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getAllItems(connection);
    List<Item> items = new ArrayList<>();
    while (results.next()) {
      int id = results.getInt("ID");
      String name = results.getString("NAME");
      BigDecimal price = new BigDecimal(results.getString("PRICE"));
      Item item = new ItemImpl(id, name, price);
      items.add(item);
    }
    results.close();
    connection.close();
    return items;
  }

  /**
   * get a specific item and it's details from the database.
   * 
   * @param itemId the item of interest.
   * @return a Item containing the information of itedId.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static Item getItem(int itemId) throws SQLException, DatabaseSelectException {
    List<Integer> itemIds = getAllItemsId();
    boolean checkExist = false;
    for (int i = 0; i < itemIds.size(); i++) {
      if (itemId == itemIds.get(i)) {
        checkExist = true;
      }
    }
    Item item = null;
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getItem(itemId, connection);
      while (results.next()) {
        int id = results.getInt("ID");
        String name = results.getString("NAME");
        BigDecimal price = new BigDecimal(results.getString("PRICE"));
        item = new ItemImpl(id, name, price);
      }
      results.close();
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return item;
  }

  /**
   * get all rows from the inventory table.
   * 
   * @return a inventory contains all items and their quantity.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static Inventory getInventory() throws SQLException, DatabaseSelectException {
    HashMap<Item, Integer> itemMap = new HashMap<Item, Integer>();
    Inventory inventory = new InventoryImpl(itemMap);
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getInventory(connection);
    while (results.next()) {
      int itemId = results.getInt("ITEMID");
      Item item = getItem(itemId);
      Integer value = results.getInt("QUANTITY");
      inventory.updateMap(item, value);
    }
    results.close();
    connection.close();
    return inventory;
  }

  /**
   * get the quantity on hand of the given item.
   * 
   * @param itemId the id of the give item.
   * @return the quantity of the given item available.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static int getInventoryQuantity(int itemId) throws SQLException, DatabaseSelectException {
    List<Integer> itemIds = getAllItemsId();
    boolean checkExist = false;
    for (int i = 0; i < itemIds.size(); i++) {
      if (itemId == itemIds.get(i)) {
        checkExist = true;
      }
    }
    int quantity = -1;
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      quantity = DatabaseSelector.getInventoryQuantity(itemId, connection);
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return quantity;
  }

  /**
   * return all sales.
   * 
   * @return a SalesLog of all sales.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static SalesLog getSales() throws SQLException, DatabaseSelectException {
    SalesLog salesLog = new SalesLogImpl();
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getSales(connection);
    while (results.next()) {
      int saleId = results.getInt("ID");
      int userId = results.getInt("USERID");
      BigDecimal totalPrice = new BigDecimal(results.getString("TOTALPRICE"));
      Sale sale = new SaleImpl(saleId, getUserDetails(userId), totalPrice);
      salesLog.addSaleLog(sale);
    }
    results.close();
    connection.close();
    return salesLog;
  }

  /**
   * get the details of a given sale.
   * 
   * @param saleId the id of the given sale.
   * @return sale of the details of a given saleId.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static Sale getSaleById(int saleId) throws SQLException, DatabaseSelectException {
    List<Integer> saleIds = getSalesId();
    boolean checkExist = false;
    for (int i = 0; i < saleIds.size(); i++) {
      if (saleId == saleIds.get(i)) {
        checkExist = true;
      }
    }
    Sale sale = null;
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getSaleById(saleId, connection);
      while (results.next()) {
        int userId = results.getInt("USERID");
        BigDecimal totalPrice = new BigDecimal(results.getString("TOTALPRICE"));
        sale = new SaleImpl(saleId, getUserDetails(userId), totalPrice);
      }
      results.close();
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return sale;
  }

  /**
   * get all sales for a given user.
   * 
   * @param userId the id of the user.
   * @return a List of sale of all sales made to the given user.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static List<Sale> getSalesToUser(int userId) throws SQLException, DatabaseSelectException {
    List<Integer> userIds = getuserIds();
    boolean checkExist = false;
    for (int i = 0; i < userIds.size(); i++) {
      if (userId == userIds.get(i)) {
        checkExist = true;
      }
    }
    List<Sale> sales = new ArrayList<>();
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelectHelper.getSalesToUser(userId, connection);
      while (results.next()) {
        int saleId = results.getInt("ID");
        Sale sale = getSaleById(saleId);
        sales.add(sale);
      }
      results.close();
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return sales;
  }

  /**
   * get the items sold in the given sale and the quantity of each.
   * 
   * @param salesId the id of the sale of interest.
   * @return A sale with all itemizedSale for the given sale.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static Sale getItemizedSaleById(int saleId) throws SQLException, DatabaseSelectException {
    List<Integer> saleIds = getSalesId();
    boolean checkExist = false;
    for (int i = 0; i < saleIds.size(); i++) {
      if (saleId == saleIds.get(i)) {
        checkExist = true;
      }
    }
    Sale sale = null;
    if (checkExist) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getItemizedSaleById(saleId, connection);
      HashMap<Item, Integer> itemMap = new HashMap<>();
      while (results.next()) {
        int itemId = results.getInt("ITEMID");
        int quantity = results.getInt("QUANTITY");
        try {
          itemMap.put(getItem(itemId), quantity);
        } catch (DatabaseSelectException e) {
        }
      }
      Sale temSale = getSaleById(saleId);
      sale = new SaleImpl(saleId, temSale.getUser(), temSale.getTotalPrice(), itemMap);
      results.close();
      connection.close();
    } else {
      throw new DatabaseSelectException();
    }
    return sale;
  }

  /**
   * get all itemized sales from the itemizedsales table.
   * 
   * @return all itemized sales.
   * @throws SQLException            if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static SalesLog getItemizedSales() throws SQLException, DatabaseSelectException {
    SalesLog salesLog = new SalesLogImpl();
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getItemizedSales(connection);
    while (results.next()) {
      int saleId = results.getInt("SALEID");
      int itemId = results.getInt("ITEMID");
      int quantity = results.getInt("QUANTITY");
      HashMap<Item, Integer> itemMap = new HashMap<>();
      try {
        itemMap.put(getItem(itemId), quantity);
      } catch (DatabaseSelectException e) {
      }
      Sale sale = new SaleImpl(saleId, itemMap);
      salesLog.addSaleLog(sale);
    }
    results.close();
    connection.close();
    return salesLog;
  }

  /**
   * Return the AccountIds of the given user.
   * 
   * @param userId the user's Id
   * @return the AccountIds
   * @throws SQLException if something went wrong
   */
  public static List<Integer> getUserAccounts(int userId) throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getUserAccounts(userId, connection);
    List<Integer> Ids = new ArrayList<>();
    while (results.next()) {
      Ids.add(results.getInt("ID"));
    }
    results.close();
    connection.close();
    return Ids;
  }

  /**
   * Provide the details of account of given accountId
   * @param accountId the account's Id
   * @return the information of the specific account which represent by a account.
   * @throws SQLException if something goes wrong
   * @throws DatabaseSelectException if we cannot find the information
   * @throws NotLoginException if there doesn't exist such a user
   */
  public static Account getAccountDetails(int accountId)
      throws SQLException, DatabaseSelectException, NotLoginException {
    // Instantialize an Account which has the input accountId
    Account temAccount = new Account(accountId);
    // Check which userId has associated with the input accountId, and get the UserDetails
    Customer temCustomer = null;
    int temUserId = 0;
      for(int  i = 0; i < DatabaseSelectHelper.getuserIds().size(); i++) {
        temUserId = DatabaseSelectHelper.getuserIds().get(i);
        for(int j = 0; j < DatabaseSelectHelper.getUserAccounts(temUserId).size(); j++) {
          int temAccountId = DatabaseSelectHelper.getUserAccounts(temUserId).get(j);
          if(temAccountId == accountId) {
            temCustomer = (Customer)DatabaseSelectHelper.getUserDetails(temUserId);
            break;
          }
        }
      }
    // check the active of account
      if(temCustomer != null) {
        if(getUserActiveAccounts(temUserId).contains(accountId)) {
          temAccount.setAccountActive(1);
        }else {
          temAccount.setAccountActive(0);
        }
      }
    // Create a shoppingcart to be stored in Account, then return the Account
    if(temCustomer != null) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getAccountDetails(accountId, connection);
      Customer customer = new Customer(temCustomer.getId(), temCustomer.getName(),
          temCustomer.getAge(), temCustomer.getAddress(), true);
      ShoppingCart temShoppingCart = new ShoppingCart(customer);
      while(results.next()) {
        int itemId = results.getInt("itemId");
        Item temItem = DatabaseSelectHelper.getItem(itemId);
        int quantity = results.getInt("quantity");
        temShoppingCart.addItem(temItem, quantity);
      }
      temAccount.setShoppingCart(temShoppingCart);
      results.close();
      connection.close();
      return temAccount;
    } else {
      return null;
    }
  }

  /**
   * Return a list of active accounts of the given userId.
   * @param userId the ID of the given user
   * @return A list of active accounts
   * @throws SQLException if something goes wrong
   */
  public static List<Integer> getUserActiveAccounts(int userId) throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getUserActiveAccounts(userId, connection);
    List<Integer> temAccountsList = new ArrayList<>();
    while(results.next()) {
      temAccountsList.add(results.getInt("ID"));
    }
    return temAccountsList;
  }

  /**
   * Return a list of inactive accounts of the given userId
   * @param userId the ID of the given user
   * @return A list of inactive accounts
   * @throws SQLException if something goes wrong
   */
  public static List<Integer> getUserInactiveAccounts(int userId) throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getUserInactiveAccounts(userId, connection);
    List<Integer> temAccountList = new ArrayList<>();
    while(results.next()) {
      temAccountList.add(results.getInt("ID"));
    }
    return temAccountList;
  }

}
