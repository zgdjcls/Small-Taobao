package com.b07.database.helper;

import com.b07.database.DatabaseInserter;
import com.b07.database.helper.DatabaseDriverHelper;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.DatabaseSelectException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseInsertHelper extends DatabaseInserter {

  /**
   * Use this to insert new roles into the database.
   * 
   * @param role the new role to be added.
   * @return the id of the role that was inserted.
   * @throws DatabaseInsertException on failure.
   * @throws SQLException if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public static int insertRole(String name) throws DatabaseInsertException, SQLException {
    int roleId = -1;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    roleId = DatabaseInserter.insertRole(name, connection);
    connection.close();
    return roleId;
  }

  /**
   * Use this to insert a new user.
   * 
   * @param name the user's name.
   * @param age the user's age.
   * @param address the user's address.
   * @param password the user's password (not hashed).
   * @return the user id
   * @throws DatabaseInsertException if there is a failure on the insert
   * @throws SQLException if something goes wrong.
   */
  public static int insertNewUser(String name, int age, String address, String password)
      throws SQLException, DatabaseInsertException {
    int userId = -1;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    userId = DatabaseInserter.insertNewUser(name, age, address, password, connection);
    connection.close();
    return userId;
  }
  
  /**
   * Use this to insert a new user.
   * 
   * @param name the user's name.
   * @param age the user's age.
   * @param address the user's address.
   * @param password the user's password (HASHED!!!).
   * @return the user id
   * @throws DatabaseInsertException if there is a failure on the insert
   * @throws SQLException if something goes wrong.
   */
  public static int insertDeserializeNewUser(String name, int age, String address, String password)
      throws SQLException, DatabaseInsertException {
    int userId = -1;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    userId = DatabaseInserter.insertDesirializeNewUser(name, age, address, password, connection);
    connection.close();
    return userId;
  }

  /**
   * Insert a relationship between a user and a role.
   * 
   * @param userId the id of the user.
   * @param roleId the role id of the user.
   * @return the unique relationship id.
   * @throws DatabaseInsertException if there is a failure on the insert.
   * @throws SQLException if something goes wrong.
   */
  public static int insertUserRole(int userId, int roleId)
      throws DatabaseInsertException, SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    int userRoleId = DatabaseInserter.insertUserRole(userId, roleId, connection);
    connection.close();
    return userRoleId;
  }

  /**
   * insert an item into the database.
   * 
   * @param name the name of the item.
   * @param price the price of the item.
   * @return the id of the inserted record.
   * @throws DatabaseInsertException if something goes wrong.
   * @throws SQLException if something goes wrong.
   */
  public static int insertItem(String name, BigDecimal price)
      throws DatabaseInsertException, SQLException {
    int itemId = -1;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    itemId = DatabaseInserter.insertItem(name, price, connection);
    connection.close();
    return itemId;
  }

  /**
   * insert inventory into the database.
   * 
   * @param itemId the id of the item.
   * @param quantity the quantity of the item.
   * @return the id of the inserted record.
   * @throws DatabaseInsertException if something goes wrong.
   * @throws SQLException if something goes wrong.
   */
  public static int insertInventory(int itemId, int quantity)
      throws DatabaseInsertException, SQLException {
    int inventoryId = -1;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    inventoryId = DatabaseInserter.insertInventory(itemId, quantity, connection);
    connection.close();
    return inventoryId;
  }

  /**
   * insert a sale into the database.
   * 
   * @param userId the id of the user.
   * @param totalPrice the total price of the sale.
   * @return the id of the inserted record.
   * @throws DatabaseInsertException if something goes wrong.
   * @throws SQLException if something goes wrong.
   */
  public static int insertSale(int userId, BigDecimal totalPrice)
      throws DatabaseInsertException, SQLException {
    int saleId = -1;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    saleId = DatabaseInserter.insertSale(userId, totalPrice, connection);
    connection.close();
    return saleId;
  }

  /**
   * insert an itemized record for a specific item in a sale.
   * 
   * @param saleId the id of the sale.
   * @param itemId the id of the item.
   * @param quantity the number of the item purchased.
   * @return the id of the inserted record.
   * @throws DatabaseInsertException if something goes wrong.
   * @throws SQLException if something goes wrong.
   */
  public static int insertItemizedSale(int saleId, int itemId, int quantity)
      throws DatabaseInsertException, SQLException {
    int itemizedId = -1;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    itemizedId = DatabaseInserter.insertItemizedSale(saleId, itemId, quantity, connection);
    connection.close();
    return itemizedId;
  }

  /**
   * 
   * @param userId the id of user
   * @return the account id of given user
   * @throws DatabaseInsertException if something goes wrong.
   * @throws SQLException if something goes wrong.
   */
  public static int insertAccount(int userId) throws DatabaseInsertException, SQLException {
    int accountId;
    boolean active = true;
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    accountId = DatabaseInserter.insertAccount(userId, active, connection);
    connection.close();
    return accountId;
  }
 /**
  * 
  * @param accountId the account id of customer
  * @param itemId the id of item
  * @param quantity the quantity of item
  * @return a record id of this operation
  * @throws DatabaseInsertException if something goes wrong
  * @throws SQLException if something goes wrong
  */
  public static int insertAccountLine(int accountId, int itemId, int quantity)
      throws DatabaseInsertException, SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    int recordId = DatabaseInserter.insertAccountLine(accountId, itemId, quantity, connection);
    connection.close();
    return recordId;
  }

}
