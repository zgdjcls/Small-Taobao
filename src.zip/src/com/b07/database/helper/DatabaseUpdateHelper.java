package com.b07.database.helper;

import com.b07.database.DatabaseUpdater;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.inventory.Item;
import com.b07.inventory.ItemTypes;
import com.b07.users.Roles;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class DatabaseUpdateHelper extends DatabaseUpdater {
  /**
   * Update the role name of a given role in the role table.
   * 
   * @param name the new name of the role.
   * @param id the current ID of the role.
   * @param connection the database connection.
   * @return true if successful, false otherwise.
   * @throws SQLException if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   * @throws DatabaseInsertException if the name is not in itemTypes
   */
  public static boolean updateRoleName(String name, int id)
      throws SQLException, DatabaseInsertException, DatabaseSelectException {
    boolean complete = false;
    boolean rightName = true;
    boolean notExisting = true;
    for (Roles role : Roles.values()) {
      if (role.name().equals(name)) {
        rightName = true;
      }
    }
    if (rightName == false) {
      throw new DatabaseInsertException();
    }
    List<Integer> roleIds = DatabaseSelectHelper.getRoleIds();
    for (int i = 0; i < roleIds.size(); i++) {
      if (name.equals(DatabaseSelectHelper.getRoleName(roleIds.get(i)))) {
        notExisting = false;
      }
    }
    boolean checkRoleExist = false;
    for(int i = 0; i < roleIds.size(); i++) {
      if(id == roleIds.get(i)){
        checkRoleExist = true;
      }
    }
    if (checkRoleExist && rightName && notExisting) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateRoleName(name, id, connection);
      connection.close();
    }
    return complete;
  }

  /**
   * Use this to update the user's name.
   * 
   * @param name the new name
   * @param id the current id
   * @return true if it works, false otherwise.
   * @throws SQLException if something goes wrong.
   */
  public static boolean updateUserName(String name, int userId) throws SQLException {
    boolean complete = false;
    boolean rightName = true;
    boolean rightId = true;
    try {
      DatabaseSelectHelper.getUserRoleId(userId);
    } catch (DatabaseSelectException e) {
      rightId = false;
    }
    if (name == null || name.isBlank() || name.length() > 64) {
      rightName = false;
    }
    if (rightId && rightName) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserName(name, userId, connection);
      connection.close();

    }
    return complete;
  }

  /**
   * Use this to update the user's age.
   * 
   * @param age the new age.
   * @param id the current id
   * @return true if it succeeds, false otherwise.
   * @throws SQLException if something goes wrong.
   */
  public static boolean updateUserAge(int age, int userId) throws SQLException {
    boolean complete = false;
    boolean rightAge = true;
    boolean rightId = true;
    try {
      DatabaseSelectHelper.getUserRoleId(userId);
    } catch (DatabaseSelectException e) {
      rightId = false;
    }
    if (age <= 0) {
      rightAge = false;
    }
    if (rightId && rightAge) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserAge(age, userId, connection);
      connection.close();
    }
    return complete;
  }

  /**
   * Use this to update user's address.
   * 
   * @param address the new address.
   * @param id the current id.
   * @return true if successful, false otherwise.
   * @throws SQLException if something goes wrong.
   */
  public static boolean updateUserAddress(String address, int userId) throws SQLException {
    boolean complete = false;
    boolean rightAddress = true;
    boolean rightId = true;
    try {
      DatabaseSelectHelper.getUserRoleId(userId);
    } catch (DatabaseSelectException e) {
      rightId = false;
    }
    if (address.equals(null) || address.isBlank() || address.length() > 100) {
      rightAddress = false;
    }
    if (rightId && rightAddress) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserAddress(address, userId, connection);
      connection.close();
    }
    return complete;

  }

  /**
   * update the role of the user.
   * 
   * @param roleId the new role.
   * @param id the current id.
   * @return true if successful, false otherwise.
   * @throws SQLException if something goes wrong.
   */
  public static boolean updateUserRole(int roleId, int userId) throws SQLException {
    boolean rightUserId = true;
    boolean complete = false;
    try {
      DatabaseSelectHelper.getUserRoleId(userId);
    } catch (DatabaseSelectException e) {
      rightUserId = false;
    }
    List<Integer> RoleIds = DatabaseSelectHelper.getRoleIds();
    boolean checkExist = false;
    for (int i = 0; i < RoleIds.size(); i++){
      if (roleId == RoleIds.get(i)){
        checkExist = true;
      }
    }
    if (checkExist && rightUserId) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserRole(roleId, userId, connection);
      connection.close();
    }
    return complete;

  }

  /**
   * Update the name of an item currently in the database.
   * 
   * @param name the new name.
   * @param id the id of the current item.
   * @return true if successful, false otherwise.
   * @throws SQLException if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   * 
   */
  public static boolean updateItemName(String name, int itemId)
      throws SQLException, DatabaseSelectException {
    boolean complete = false;
    boolean rightId = true;
    boolean rightName = true;
    boolean notExisting = true;
    try {
      DatabaseSelectHelper.getItem(itemId);
    } catch (DatabaseSelectException e) {
      rightId = false;
    }
    for (ItemTypes item : ItemTypes.values()) {
      if (item.name().equals(name)) {
        rightName = true;
      }
    }
    if (rightName = false) {
      throw new DatabaseSelectException();
    }
    List<Item> items = DatabaseSelectHelper.getAllItems();
    for (int i = 0; i < items.size(); i++) {
      if (name.equals(items.get(i).getName())) {
        notExisting = false;
      }
    }
    if (rightId && rightName && notExisting) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateItemName(name, itemId, connection);
      connection.close();
    }
    return complete;

  }

  /**
   * update the price of an item in the database.
   * 
   * @param price the new price for the item.
   * @param id the id of the item.
   * @return true if successful, false otherwise.
   * @throws SQLException if something goes wrong.
   */
  public static boolean updateItemPrice(BigDecimal price, int itemId) throws SQLException {
    boolean complete = false;
    boolean rightId = true;
    boolean rightPrice = true;
    try {
      DatabaseSelectHelper.getItem(itemId);
    } catch (DatabaseSelectException e) {
      rightId = false;
    }
    if (price.doubleValue() <= 0 || price.scale() != 2) {
      rightPrice = false;
    }
    if (rightId && rightPrice) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateItemPrice(price, itemId, connection);
      connection.close();
    }
    return complete;
  }

  /**
   * update the quantity available in inventory for a given item.
   * 
   * @param quantity the new quantity.
   * @param itemId the item to be updated.
   * @return true if successful, false otherwise.
   * @throws SQLException if something goes wrong.
   */
  public static boolean updateInventoryQuantity(int quantity, int itemId) throws SQLException {
    boolean complete = false;
    boolean rightId = true;
    boolean rightQuantity = true;
    try {
      DatabaseSelectHelper.getItem(itemId);
    } catch (DatabaseSelectException e) {
      rightId = false;
    }
    if (quantity < 0) {
      rightQuantity = false;
    }
    if (rightId && rightQuantity) {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateInventoryQuantity(quantity, itemId, connection);
      connection.close();
    }
    return complete;
  }

  public static boolean updateAccountStatus(int accountId, boolean active) throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    boolean completed = DatabaseUpdater.updateAccountStatus(accountId, active, connection);
    connection.close();
    return completed;
  }
}
