package com.b07.users;

public class Account implements AccountInterface {
  /**
   *  Serial ID.
   */
  private static final long serialVersionUID = 13465L;
  private ShoppingCart storedCart;
  private int accountId;
  private int active = 1;

  public Account(int accountId) {
    this.accountId = accountId;
  }
  @Override
  public void setShoppingCart(ShoppingCart cart) {
    this.storedCart = cart;
  }

  @Override
  public ShoppingCart getShoppingCart() {
    return this.storedCart;
  }

  @Override
  public void setAccountId(int accountId) {
    this.accountId = accountId;
  }

  @Override
  public int getAccountId() {
    return this.accountId;
  }

  @Override
  public int getAccountActive() {
    return this.active;
  }

  @Override
  public void setAccountActive(int active) {
    this.active = active;
  }
}
