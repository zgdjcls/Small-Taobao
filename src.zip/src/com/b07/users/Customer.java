package com.b07.users;

public class Customer extends User {
  private int id;
  private String name;
  private int age;
  private String address;
  private int roleId;
  private transient boolean authenticated;
  
  public Customer(int id, String name, int age, String address) {
    super(id,name,age,address);
  }
  
  public Customer(int id, String name, int age, String address, boolean authenticated) {
    super(id,name,age,address);
    this.authenticated = authenticated;
  }
  /**
   * 
   * @return true if authenticated is true, false otherwise
   */
  protected boolean getAuthenticated() {
    return this.authenticated;
  }
}
