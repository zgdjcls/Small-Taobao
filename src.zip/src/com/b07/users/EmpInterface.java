package com.b07.users;

import java.io.Serializable;
import java.sql.SQLException;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.inventory.Item;

public interface EmpInterface extends Serializable {

  /**
   * Set input employee as current Employee.
   * @param employee the employee that is set.
   * @throws SQLException
   */
  public void setCurrentEmployee(Employee employee) throws SQLException;
  
  /**
   * @return true if currentEmployee is not null
   */
  public boolean hasCurrentEmployee();

  /**
   * 
   * @param item an item in itemTypes
   * @param quantity quantity of item
   * @return update the new quantity of item in database
   * @throws SQLException
   */
  public boolean restockInventory(Item item, int quantity) throws SQLException;

  /**
   * 
   * @param name a not empty name and less than 64 characters
   * @param age an age
   * @param address an address and less than 100 characters
   * @param password not empty password
   * @return true if create a new Customer
   * @throws DatabaseInsertException if input is not valid
   * @throws SQLException if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid
   */
  public int createCustomer(String name, int age, String address, String password)
      throws DatabaseInsertException, SQLException, DatabaseSelectException;
  
  /**
   * 
   * @param name a not empty name and less than 64 characters
   * @param age an age
   * @param address an address and less than 100 characters
   * @param password not empty password
   * @return true if create a new Employee
   * @throws DatabaseInsertException if input is not valid
   * @throws SQLException if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid
   */
  public int createEmployee(String name, int age, String address, String password)
      throws DatabaseInsertException, SQLException, DatabaseSelectException;

}
