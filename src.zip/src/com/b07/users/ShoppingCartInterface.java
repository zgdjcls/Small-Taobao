package com.b07.users;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.inventory.Item;

public interface ShoppingCartInterface extends Serializable {
  
  /**
   * 
   * @param item an item in itmeTypes
   * @param quantity quantity of item need to be added
   * @throws SQLException if something goes wrong
   */
  public void addItem(Item item, int quantity) throws SQLException;
  
  /**
   * 
   * @param item an item in itmeTypes
   * @param quantity quantity of item need to be removed
   * @throws SQLException if something goes wrong
   */
  public void removeItem(Item item, int quantity) throws SQLException;
  
  /**
   * @return return the list of all items
   */
  public List<Item> getItems();
  
  /**
   * @return return the Customer of this Shoppingcart.
   */
  public Customer getCustomer();

  /**
   * @return return the total price of the items in the Shoppingcart.
   */
  public BigDecimal getTotal();

  /**
   * @return return the TaxRate of the Customer which is fixed.
   */
  public BigDecimal getTaxRate();

  /**
   * clear the Cart.
   */
  public void clearCart();
  
  /**
   * 
   * @return calculate the price after TAXRATE and clear the cart, insert this sale to database with some itemizedSales
   * @throws SQLException if something goes wrong
   * @throws DatabaseSelectException if input is not valid 
   * @throws DatabaseInsertExceptionif input is not valid
   */
  public boolean checkOut() throws SQLException, DatabaseSelectException, DatabaseInsertException;
  /**
   * 
   * @return the HashMap of this shoppingCart
   */
  public HashMap<Item,Integer> getItemsWithQuantity();
}
