package com.b07.users;

import java.io.Serializable;

public interface AccountInterface extends Serializable {


  /**
  * Store the current shoppingcart for this user.
  * @param cart the current cart of this user
  */
  public void setShoppingCart(ShoppingCart cart);

  /**
   * Restore the shopping cart stored inside the database of
   * specific user.
   * @return return the cart
   */
  public ShoppingCart getShoppingCart();

  /**
   * Set input AccountId as this Account's Id.
   * @param accountId the Id that will use as this AccountId
   */
  public void setAccountId(int accountId);
  
  /**
   * Get this Account's Id
   * @return this Account's Id
   */
  public int getAccountId();

  /**
   * Get this Account statu which is active or not.
   * @return True if the account is active, otherwise False.
   */
  public int getAccountActive();
  
  /**
   * Set the statu of this account True or False.
   * @param active the boolean value that makes the account active 
   * or inactive.
   */
  public void setAccountActive(int active);
}