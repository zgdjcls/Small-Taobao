package com.b07.users;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.exceptions.NotLoginException;
import com.b07.inventory.Item;

public class ShoppingCart implements ShoppingCartInterface {
  /**
   * Serial ID.
   */
  private static final long serialVersionUID = 114514L;
  private HashMap<Item, Integer> items;
  private Customer customer;
  private BigDecimal total;
  private static final BigDecimal TAXRATE = new BigDecimal("1.13");

  public ShoppingCart(Customer customer) throws NotLoginException {
    if(customer == null) {
      this.items = new HashMap<Item, Integer>();
      this.total = new BigDecimal("0.00");
    }else if (customer.getAuthenticated()) {
      this.customer = customer;
      this.items = new HashMap<Item, Integer>();
      this.total = new BigDecimal("0.00");
    } else {
      throw new NotLoginException();
    }
  }

  @Override
  public void addItem(Item item, int quantity) throws SQLException {
    boolean exist = false;
    for (Item itemInCart : items.keySet()) {
      if (itemInCart.getId() == item.getId()) {
        item = itemInCart;
        exist = true;
        break;
      }
    }
    if (exist) {
      int currentQuantity = items.get(item);
      items.put(item, quantity + currentQuantity);
    } else {
      items.put(item, quantity);
    }
    BigDecimal quantities = new BigDecimal(((Integer) quantity).toString());
    total = total.add(item.getPrice().multiply(quantities));

  }

  @Override
  public void removeItem(Item item, int quantity) throws SQLException {
    boolean exist = false;
    for (Item itemInCart : items.keySet()) {
      if (itemInCart.getId() == item.getId()) {
        item = itemInCart;
        exist = true;
        break;
      }
    }
    if (exist && items.get(item) - quantity > 0) {
      int currentQuantity = items.get(item);
      items.put(item, currentQuantity - quantity);
      BigDecimal quantities = new BigDecimal(((Integer) quantity).toString());
      total = total.subtract((item.getPrice().multiply(quantities)));
    } else if (exist && quantity > 0) {
      int currentQuantity = items.get(item);
      items.remove(item);
      BigDecimal quantities = new BigDecimal(((Integer) currentQuantity).toString());
      total = total.subtract((item.getPrice().multiply(quantities)));
    }else if(!exist) {
      System.out.println("No " + item.getName() + " in your cart, the system cannot remove it");
    }
  }

  @Override
  public List<Item> getItems() {
    List<Item> items = new ArrayList<>();
    Object[] keySet = this.items.keySet().toArray();
    for (int i = 0; i < keySet.length; i++) {
      items.add((Item) keySet[i]);
    }
    return items;
  }

  @Override
  public Customer getCustomer() {
    return this.customer;
  }

  @Override
  public BigDecimal getTotal() {
    return this.total;
  }

  @Override
  public BigDecimal getTaxRate() {
    return ShoppingCart.TAXRATE;
  }

  @Override
  public void clearCart() {
    this.items.clear();
    this.total = new BigDecimal("0.00");
  }

  @Override
  public boolean checkOut() throws SQLException, DatabaseSelectException, DatabaseInsertException {
    List<Item> items = getItems();
    for (int i = 0; i < items.size(); i++) {
      int quantity = this.items.get(items.get(i));
      try {
        DatabaseSelectHelper.getInventoryQuantity(items.get(i).getId());
      } catch (SQLException e) {
        removeItem(items.get(i), quantity);
        System.out
            .println("No " + items.get(i).getName() + "in stock, so we remove it from your cart");
      }
      if (quantity > DatabaseSelectHelper.getInventoryQuantity(items.get(i).getId())) {
        removeItem(items.get(i),
            quantity - DatabaseSelectHelper.getInventoryQuantity(items.get(i).getId()));
        System.out.println("There only has "
            + DatabaseSelectHelper.getInventoryQuantity(items.get(i).getId()) + " "
            + items.get(i).getName() + "(s) in stock, so we change the quantity in your cart");
      }
    }
    BigDecimal totalAfterTax = total.multiply(TAXRATE);
    int saleId = DatabaseInsertHelper.insertSale(this.customer.getId(), totalAfterTax);
    for (int i = 0; i < items.size(); i++) {
      int quantity = this.items.get(items.get(i));
      int currentQuantity = DatabaseSelectHelper.getInventoryQuantity(items.get(i).getId());
      DatabaseUpdateHelper.updateInventoryQuantity(currentQuantity - quantity,
          items.get(i).getId());
      DatabaseInsertHelper.insertItemizedSale(saleId, items.get(i).getId(), quantity);
    }
    clearCart();
    total = new BigDecimal("0.00");
    return true;
  }

  @Override
  public HashMap<Item, Integer> getItemsWithQuantity() {
    return this.items;
  }
}

