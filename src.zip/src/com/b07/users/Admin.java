package com.b07.users;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.exceptions.NotLoginException;
import com.b07.inventory.Item;
import com.b07.store.Sale;
import com.b07.store.SalesLog;

public class Admin extends User {
  private int id;
  private String name;
  private int age;
  private String address;
  private int roleId;
  private transient boolean authenticated;

  public Admin(int id, String name, int age, String address) {
    super(id, name, age, address);
  }

  public Admin(int id, String name, int age, String address, boolean authenticated) {
    super(id, name, age, address);
    this.authenticated = authenticated;
  }

  /**
   * 
   * @param employee an employee need to be promoted to Admin.
   * @return true if promote sucessfully, false otherwise.
   * @throws SQLException if something goes wrong.
   * @throws DatabaseSelectException if the input is invalid.
   */
  public boolean promoteEmployee(Employee employee) throws SQLException, DatabaseSelectException {
    List<Integer> roleIds = DatabaseSelectHelper.getRoleIds();
    int adminId = -1;
    for (int i = 0; i < roleIds.size(); i++) {
      if (DatabaseSelectHelper.getRoleName(roleIds.get(i)).equals("ADMIN")) {
        adminId = roleIds.get(i);
      }
    }
    return DatabaseUpdateHelper.updateUserRole(adminId, employee.getId());
  }

  /**
   * this method prints all sales stored in the database, follow the format of the handout
   * 
   * @throws NotLoginException if something goes wrong
   * @throws SQLException if something goes wrong
   * @throws DatabaseSelectException if something goes wrong
   */
  public void printSales() throws NotLoginException, SQLException, DatabaseSelectException {
    Customer customer = new Customer(0, "printsale", 0, "printsale", true);
    ShoppingCart total = new ShoppingCart(customer);
    BigDecimal totalPrice = new BigDecimal("0.00");
    SalesLog salesLog = DatabaseSelectHelper.getSales();
    List<Sale> allSales = salesLog.getSalesLog();
    for (int i = 0; i < allSales.size(); i++) {
      Sale sale = DatabaseSelectHelper.getItemizedSaleById(allSales.get(i).getId());
      System.out.println("Customer: <<" + sale.getUser().getName() + ">>");
      System.out.println("Purchase Number: <<" + sale.getId() + ">>");
      System.out.println("Total Purchase Price: <<" + sale.getTotalPrice() + ">>");
      totalPrice = totalPrice.add(sale.getTotalPrice());
      System.out.print("Itemized Breakdown: ");
      int j = 0;
      for (Item item : sale.getItemMap().keySet()) {
        if (j > 0) {
          System.out.print("                   ");
        }
        System.out.print("<<" + item.getName() + ">>: ");
        System.out.println("<<" + sale.getItemMap().get(item) + ">>");
        j++;
        total.addItem(item, sale.getItemMap().get(item));
      }
      System.out.println("----------------------------------------------------------------");
    }
    for (Item item : total.getItemsWithQuantity().keySet()) {
      System.out.println("Number <<" + item.getName() + ">> Sold: <<"
          + total.getItemsWithQuantity().get(item) + ">>");
    }
    System.out.println("TOTAL SALES: <<" + totalPrice.toString() + ">>");
  }

  /**
   * Return a list of Accounts, which can see the detail in the account.
   * 
   * @param userId the given userId
   * @param active the status of accounts in the list, only accept 0 or 1, otherwise return NULL
   * @return A list of active or inactive accounts depends on the active
   * @throws SQLException if the Sql cannot read or load
   * @throws DatabaseSelectException if there isn't any info of given user's account
   * @throws NotLoginException if the user does not exist in database
   */
  public List<Account> getAccounts(int userId, int active)
      throws SQLException, DatabaseSelectException, NotLoginException {
    if (active == 1) {
      List<Account> activeAccount = new ArrayList<>();
      for (int i = 0; i < DatabaseSelectHelper.getUserActiveAccounts(userId).size(); i++) {
        int temAccountId = DatabaseSelectHelper.getUserActiveAccounts(userId).get(i);
        Account temAccount = DatabaseSelectHelper.getAccountDetails(temAccountId);
        activeAccount.add(temAccount);
      }
      return activeAccount;
    } else if (active == 0) {
      List<Account> inactiveAccount = new ArrayList<>();
      for (int i = 0; i < DatabaseSelectHelper.getUserInactiveAccounts(userId).size(); i++) {
        int temAccountId = DatabaseSelectHelper.getUserInactiveAccounts(userId).get(i);
        Account temAccount = DatabaseSelectHelper.getAccountDetails(temAccountId);
        inactiveAccount.add(temAccount);
      }
      return inactiveAccount;
    } else {
      return null;
    }
  }
}
