package com.b07.users;

import com.b07.security.*;

import java.io.Serializable;
import java.sql.SQLException;
import com.b07.database.helper.*;
import com.b07.exceptions.DatabaseSelectException;

public abstract class User implements Serializable {
  /**
   *  Serial ID.
   */
  private static final long serialVersionUID = 1L;
  private int id;
  private String name;
  private int age;
  private String address;
  private int roleId;
  private transient boolean authenticated;

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getAge() {
    return this.age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public String getAddress() {
    return this.address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public int getRoleId() {
    return this.roleId;
  }

/**
 * 
 * @param password a not empty password
 * @return true if we have same password in database
 * @throws SQLException if something goes wrong
 * @throws DatabaseSelectException if id is invalid
 */
  public final boolean authenticate(String password) throws SQLException, DatabaseSelectException {
    String dbPassword = null;
    try{
      dbPassword = DatabaseSelectHelper.getPassword(id);
    }catch(DatabaseSelectException e) {}
    if(PasswordHelpers.comparePassword(dbPassword, password)) {
      authenticated = true;
    } else {
      authenticated = false;
    }
    return authenticated;
  }

  protected User(int id, String name, int age, String address) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.address = address;
  } 
}
