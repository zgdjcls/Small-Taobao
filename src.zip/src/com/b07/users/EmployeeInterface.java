package com.b07.users;

import java.sql.SQLException;
import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.DatabaseSelectException;
import com.b07.inventory.Inventory;
import com.b07.inventory.Item;

public class EmployeeInterface implements EmpInterface {
  /**
   *  Serial ID.
   */
  private static final long serialVersionUID = 1465798L;
  private Employee currentEmployee;
  private Inventory inventory;

  public EmployeeInterface(Employee employee, Inventory inventory) throws SQLException {
    if (employee.getAuthenticated()) {
      this.currentEmployee = employee;
      this.inventory = inventory;
    }
  }

  public EmployeeInterface(Inventory inventory) {
    this.inventory = inventory;
  }

  @Override
  public void setCurrentEmployee(Employee employee) throws SQLException {
    if (employee.getAuthenticated()) {
      this.currentEmployee = employee;
    }
  }
  
  @Override
  public boolean hasCurrentEmployee() {
    if (this.currentEmployee != null) {
      return true;
    }
    return false;
  }
  
  @Override
  public boolean restockInventory(Item item, int quantity) throws SQLException {
    boolean rightUpdate = true;
    try {
      DatabaseSelectHelper.getItem(item.getId());
    } catch (DatabaseSelectException e) {
      rightUpdate = false;
    }
    if (quantity < 0) {
      rightUpdate = false;
    }
    if (rightUpdate) {
      rightUpdate = DatabaseUpdateHelper.updateInventoryQuantity(quantity, item.getId());
    }
    return rightUpdate;
  }

  @Override
  public int createCustomer(String name, int age, String address, String password)
      throws DatabaseInsertException, SQLException, DatabaseSelectException {
    int userId = DatabaseInsertHelper.insertNewUser(name, age, address, password);
    int roleId = DatabaseInsertHelper.insertRole("CUSTOMER");
    DatabaseInsertHelper.insertUserRole(userId, roleId);
    return userId;
  }
  
  @Override
  public int createEmployee(String name, int age, String address, String password) throws DatabaseInsertException, SQLException, DatabaseSelectException {
    int userId = DatabaseInsertHelper.insertNewUser(name, age, address, password);
    int roleId = DatabaseInsertHelper.insertRole("EMPLOYEE");
    DatabaseInsertHelper.insertUserRole(userId, roleId);
    return userId;
  }

}
