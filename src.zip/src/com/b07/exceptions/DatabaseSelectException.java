package com.b07.exceptions;

public class DatabaseSelectException extends Exception {

  /**
   * serialID for select exceptions.
   */
  private static final long serialVersionUID = 1L;

}
