package com.b07.exceptions;

public class NotLoginException extends Exception {

  /**
   * serialID for insert exceptions.
   */
  private static final long serialVersionUID = 1L;

}
