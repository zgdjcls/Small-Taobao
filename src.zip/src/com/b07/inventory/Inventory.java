package com.b07.inventory;

import java.io.Serializable;
import java.util.HashMap;

public interface Inventory extends Serializable {
  public HashMap<Item, Integer> getItemMap();
  public void setItemMap(HashMap<Item, Integer> itemMap);

  /**
   * update the item map.
   * @param item the item
   * @param value the quantity of item
   */
  public void updateMap(Item item, Integer value);
  public int getTotalItems();
  public void setTotalItems(int total);
}
