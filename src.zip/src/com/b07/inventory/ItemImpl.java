package com.b07.inventory;

import java.math.BigDecimal;

public class ItemImpl implements Item {

  /**
   *  Serial ID.
   */
  private static final long serialVersionUID = 1252L;
  private int id;
  private String name;
  private BigDecimal price;

  public ItemImpl() {
    this.id = -1;
    this.name = "";
    this.price = new BigDecimal("0.00");
  }

  public ItemImpl(int id, String name, BigDecimal price) {
    this.id = id;
    this.name = name;
    this.price = price;
  }

  @Override
  public int getId() {
    return this.id;
  }

  @Override
  public void setId(int id) {
    this.id = id;
  }

  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public void setName(String name) {
    this.name = name;
  }

  @Override
  public BigDecimal getPrice() {
    return this.price;
  }

  @Override
  public void setPrice(BigDecimal price) {
    this.price = price;
  }
}
