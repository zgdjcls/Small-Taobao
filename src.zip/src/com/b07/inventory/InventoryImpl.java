package com.b07.inventory;

import java.util.HashMap;

public class InventoryImpl implements Inventory {

  /**
   *  Serial ID.
   */
  private static final long serialVersionUID = 1L;
  HashMap<Item, Integer> itemMap;
  private int total = -1;;

  public InventoryImpl() {
    HashMap<Item, Integer> itemMap = new HashMap<>();
    this.itemMap = itemMap;
  }

  public InventoryImpl(HashMap<Item, Integer> itemMap) {
    this.itemMap = itemMap;
  }

  public InventoryImpl(HashMap<Item, Integer> itemMap, int total) {
    this.itemMap = itemMap;
    this.total = total;
  }

  @Override
  public HashMap<Item, Integer> getItemMap() {
    return this.itemMap;
  }

  @Override
  public void setItemMap(HashMap<Item, Integer> itemMap) {
    this.itemMap = itemMap;
  }

  /**
   * 
   * @param item the item
   * @param value the quantity of item
   */
  @Override
  public void updateMap(Item item, Integer value) {
    if (itemMap.containsKey(item)) {
      // check whether the value exceed the total
      if (total == -1 || (value <= total && value >= 0)) {
        itemMap.replace(item, value);
      }

    } else {
      if (total == -1 || (value <= total && value >= 0)) {
        itemMap.put(item, value);
      }
    }

  }

  @Override
  public int getTotalItems() {
    return total;
  }

  @Override
  public void setTotalItems(int total) {
    if (total >= 0) {
      this.total = total;
    }
  }
}
