package com.b07.inventory;

public enum ItemTypes {
  /**
   * Declare the item type.
   */
  FISHING_ROD, HOCKEY_STICK, SKATES, RUNNING_SHOES, PROTEIN_BAR,
}
